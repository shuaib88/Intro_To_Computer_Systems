my compiler:

in order to run:
    Go to commmand line and type python3 JackAnalyzer.py directoryPath or filePath. My outputted xml will be in the
    starting directory with "Shuaib" appended to the name


in order to test:
    i used new line in order to make more readable, please use https://www.diffchecker.com/diff in order
    to check my work with the submitted solutions

    you can also use the built in TextComparer.sh

contents:
    I have a jack tokenizer, which iterates through whole file and creates tokens
    I have a jack analyzer, which drives the application
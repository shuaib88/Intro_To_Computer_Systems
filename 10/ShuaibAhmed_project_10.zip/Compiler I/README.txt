my compiler:

in order to run:
    Go to commmand line and type python3 directoryPath or filePath. My outputted xml will be in the
    starting directory with "Shuaib" appended to the name


in order to test:
    i used new line in order to make more readable, please use https://www.diffchecker.com/diff in order
    to check my work with the submitted solutions

progress:
    Tested tokenizer -- works on every single file

    Working through analyzer -- so far have ExpressionlessSquare -- Main -- fully working, SquareGame partially working

    currently I'm stuck debugging so the program will not return please ctrl + c and check the output
RUN GAME:
you can run my game by loading the directory MyGame in the VMEmulator

NOTES:
my program was built off of the square game
I added an additional component pellets that randomly spray on the screen
I attempted to get the square to eat the pellets and grow
It did grow, however it didn't eat the other pellets 


